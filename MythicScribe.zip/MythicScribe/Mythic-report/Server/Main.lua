local reports = {}

RegisterServerEvent("mythic:report:submit")
AddEventHandler("mythic:report:submit", function(data)
    local src = source
    local report = {
        id = #reports + 1,
        type = data.type,
        title = data.title,
        description = data.description,
        player = GetPlayerName(src),
        playerId = src,
        resolved = false
    }
    table.insert(reports, report)

    for _, admin in ipairs(GetPlayers()) do
        if IsPlayerAceAllowed(admin, "mythic.report.view") then
            TriggerClientEvent("mythic:report:new", admin, report)
        end
    end
end)

RegisterCommand("reports", function(source)
    if IsPlayerAceAllowed(source, "mythic.report.view") then
        TriggerClientEvent("mythic:report:openAdminUI", source, reports)
    end
end)

RegisterServerEvent("mythic:report:markResolved")
AddEventHandler("mythic:report:markResolved", function(id)
    if reports[id] then
        reports[id].resolved = true
    end
end)