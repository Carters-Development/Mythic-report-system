window.addEventListener("message", function(event) {
  if (event.data.action === "openReportUI") {
    document.getElementById("reportBox").style.display = "block";
  }
});

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
  });
});

document.getElementById("sendBtn").addEventListener("click", () => {
  const type = document.querySelector(".tab.active").dataset.type;
  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;

  fetch(`https://${GetParentResourceName()}/submitReport`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type, title, description })
  }).then(() => {
    document.getElementById("reportBox").style.display = "none";
    fetch(`https://${GetParentResourceName()}/closeUI`, { method: "POST" });
  });
});

function closeUI() {
  document.getElementById("reportBox").style.display = "none";
  fetch(`https://${GetParentResourceName()}/closeUI`, { method: "POST" });
}